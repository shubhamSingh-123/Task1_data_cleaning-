# Task1 — Automated Data Cleaning (Pro)

This repository contains a professional, ready-to-upload project that automatically detects and cleans datasets (CSV/Excel) inside a ZIP archive.

## Features
- Detects CSV or Excel (.xlsx) files inside a ZIP archive.
- Removes duplicate rows and fills missing values.
- Standardizes column names to `lower_case_with_underscores`.
- Works locally and in Google Colab.
- Includes example data, a Jupyter demo notebook, and sample cleaned output.

## Folder structure
```
Task1_Data_Cleaning_Pro/
├── README.md
├── code/
│   └── auto_clean.py
├── data/
│   └── sample_data.zip
├── results/
│   └── cleaned_dataset.csv
├── notebooks/
│   └── data_cleaning_demo.ipynb
└── requirements.txt
```

## Requirements
This project uses:
- pandas
- numpy
- openpyxl

Install with:
```bash
pip install -r requirements.txt
```

## Usage (local)
1. Place your ZIP file inside `data/` (or provide its path when prompted).
2. Run the script:
```bash
python code/auto_clean.py
```
3. Enter the path to the ZIP (e.g., `data/sample_data.zip`) when prompted.
4. Cleaned CSV will be saved in `results/cleaned_dataset.csv`.

## Usage (Google Colab)
- Upload `code/auto_clean.py` and `data/sample_data.zip` to Colab and run the script or use the notebook in `notebooks/`.

## Demo
Open `notebooks/data_cleaning_demo.ipynb` for a step-by-step demo showing before/after and basic summaries.

---
