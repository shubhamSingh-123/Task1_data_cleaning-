"""Auto Data Cleaning Script (Pro)
Usage: python code/auto_clean.py
The script will prompt for a ZIP path (e.g. data/sample_data.zip) and produce results/cleaned_dataset.csv
"""
import zipfile, os, sys, pandas as pd

def unzip_data(zip_file, extract_dir="unzipped_data"):
    os.makedirs(extract_dir, exist_ok=True)
    with zipfile.ZipFile(zip_file, 'r') as z:
        z.extractall(extract_dir)
    print(f"✅ Extracted to: {extract_dir}")
    return extract_dir

def detect_files(folder):
    csv_files, xlsx_files = [], []
    for root, _, files in os.walk(folder):
        for f in files:
            if f.lower().endswith('.csv'):
                csv_files.append(os.path.join(root, f))
            elif f.lower().endswith(('.xlsx', '.xls')):
                xlsx_files.append(os.path.join(root, f))
    return csv_files, xlsx_files

def read_file(file_path):
    if file_path.lower().endswith('.csv'):
        return pd.read_csv(file_path)
    else:
        return pd.read_excel(file_path)

def clean_data(df):
    df = df.copy()
    df = df.drop_duplicates()
    df = df.fillna('Unknown')
    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
    return df

def save_cleaned(df, output_dir='results', file_name='cleaned_dataset.csv'):
    os.makedirs(output_dir, exist_ok=True)
    out = os.path.join(output_dir, file_name)
    df.to_csv(out, index=False)
    print(f"🎉 Cleaned dataset saved to: {out}")
    return out

def main():
    if len(sys.argv) > 1:
        zip_path = sys.argv[1]
    else:
        zip_path = input('📦 Enter path to your ZIP file (e.g., data/sample_data.zip): ').strip()
    if not os.path.exists(zip_path):
        print('❌ ZIP path not found:', zip_path)
        return
    extracted = unzip_data(zip_path)
    csv_files, xlsx_files = detect_files(extracted)
    if not csv_files and not xlsx_files:
        print('❌ No CSV/XLSX found in the ZIP.')
        return
    file_to_read = csv_files[0] if csv_files else xlsx_files[0]
    print('📄 Reading file:', file_to_read)
    df = read_file(file_to_read)
    df_clean = clean_data(df)
    save_cleaned(df_clean)

if __name__ == '__main__':
    main()
