
"""Auto Data Cleaning Script"""
import zipfile, os, pandas as pd

def unzip_data(zip_file, extract_dir="unzipped_data"):
    os.makedirs(extract_dir, exist_ok=True)
    with zipfile.ZipFile(zip_file, 'r') as z:
        z.extractall(extract_dir)
    return extract_dir

def detect_files(folder):
    csv_files, xlsx_files = [], []
    for root, _, files_in_dir in os.walk(folder):
        for f in files_in_dir:
            if f.endswith(".csv"):
                csv_files.append(os.path.join(root, f))
            elif f.endswith(".xlsx"):
                xlsx_files.append(os.path.join(root, f))
    return csv_files, xlsx_files

def read_file(csv_files, xlsx_files):
    if csv_files:
        return pd.read_csv(csv_files[0])
    elif xlsx_files:
        return pd.read_excel(xlsx_files[0])
    else:
        raise FileNotFoundError("No CSV or XLSX file found!")

def clean_data(df):
    df = df.drop_duplicates()
    df = df.fillna("Unknown")
    df.columns = df.columns.str.lower().str.replace(" ", "_")
    return df

def save_cleaned(df, output_dir="results", file_name="cleaned_dataset.csv"):
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, file_name)
    df.to_csv(path, index=False)
    return path
