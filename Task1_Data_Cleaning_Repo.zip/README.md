
# Task1 Data Cleaning

Automated data cleaning for CSV/Excel files in a ZIP.

## Folder Structure
- code/: Python cleaning script
- data/: Original ZIPs
- results/: Cleaned datasets
- notebooks/: Demo notebooks

## Usage
1. Place your ZIP in data/
2. Run: python code/auto_clean.py
3. Cleaned CSV saved in results/

## Cleaning Steps
- Remove duplicates
- Fill missing values with 'Unknown'
- Standardize column names
